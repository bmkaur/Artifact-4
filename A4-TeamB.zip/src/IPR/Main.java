/**
 * @class     Main
 * @version   0.01
 * @date      8 November 2010
 * @author     Team B
 */

package IPR;

public class Main {

    public static void main(String[] args) {
    			

        MainForm.main(args);// Call the main form (MainForm)
    }
}
